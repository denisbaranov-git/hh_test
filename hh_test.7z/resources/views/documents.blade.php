<!DOCTYPE html>
<html>
<head>
    <!-- ... -->
    @vite(['resources/js/app.js'])
</head>
<body>
<div id="app">
    <items-component></items-component>
</div>
</body>
</html>
