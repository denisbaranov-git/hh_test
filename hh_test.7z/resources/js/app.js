import './bootstrap';
import { createApp } from 'vue'

//import App from './components/App.vue';

const app = createApp({})
//const app = createApp(App);

app.mount('#app')
