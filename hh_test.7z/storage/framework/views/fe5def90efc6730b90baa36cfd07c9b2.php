<!DOCTYPE html>
<html>
<head>
    <!-- ... -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
<div id="app">
    <items-component></items-component>
</div>
</body>
</html>
<?php /**PATH C:\Users\user\PhpstormProjects\hh_test\resources\views/documents.blade.php ENDPATH**/ ?>